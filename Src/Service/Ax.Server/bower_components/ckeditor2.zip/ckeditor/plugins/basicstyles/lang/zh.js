﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'zh', {
	bold: '粗體',
	italic: '斜體',
	strike: '刪除線',
	subscript: '下標',
	superscript: '上標',
	underline: '底線'
} );
