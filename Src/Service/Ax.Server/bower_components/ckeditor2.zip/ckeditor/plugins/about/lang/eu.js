﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'eu', {
	copy: 'Copyright &copy; $1. Eskubide guztiak erreserbaturik.',
	dlgTitle: 'CKEditor 4ri buruz',
	moreInfo: 'Lizentziari buruzko informazioa gure webgunean:'
} );
