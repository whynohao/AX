﻿/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","fa",{
	"alt":"متن جایگزین",
	"lockRatio":"قفل کردن نسبت",
	"vSpace":"فاصلهٴ عمودی",
	"hSpace":"فاصلهٴ افقی",
	"border":"لبه"
});
