﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'ko', {
	copy: '저작권 &copy; $1 . 판권 소유.',
	dlgTitle: 'CKEditor 에 대하여',
	moreInfo: '라이선스에 대한 정보는 저희 웹 사이트를 참고하세요:'
} );
